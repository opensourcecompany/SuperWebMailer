-----------------------------------------------------------------------------
                         SuperWebMailer WordPress Plugin
-----------------------------------------------------------------------------

Infos zur Installation http://www.superwebmailer.de/wordpress/