-----------------------------------------------------------------------------
                         SuperWebMailer WordPress Plugin
-----------------------------------------------------------------------------

Infos zur Installation https://www.superwebmailer.de/wordpress/